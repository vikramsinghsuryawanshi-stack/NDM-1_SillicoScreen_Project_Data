import os, sys
from subprocess import Popen, PIPE, STDOUT, call

file = open('mdhistory.log', 'w')

d = os.getcwd()
subdirs = ['RI139705_R3','RI207386_R3'] 
# subdirs = [x[0] for x in os.walk(cwd)]
#subdirs = [os.path.join(d, o) for o in os.listdir(d) if os.path.isdir(os.path.join(d,o))]
for folder in subdirs:
    if os.path.join(d, folder):
        os.chdir(os.path.join(d, folder))
        file.write(os.path.join(d, folder))
        print(os.path.join(d, folder))
        file.write("######################  Project folder : "+folder+" currently Working #######################")
        try:
            cmd = "./job.sh"
            output = Popen(cmd, shell=True, stdin=PIPE, stdout=PIPE, stderr=STDOUT)
            result = output.communicate()
            file.write("######################  Project folder : "+folder+" completed. #######################")
        except:
            file.write("######################  Project folder : "+folder+" currently working. #######################")
            file.write(result[0].encode('utf-8'))
            print(result[0].encode('utf-8'))


file.close()
